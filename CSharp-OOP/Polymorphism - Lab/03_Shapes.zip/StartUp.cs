﻿using Shapes.Models;

namespace Shapes
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Circle circle = new Circle(double.Parse(Console.ReadLine()));
            Console.WriteLine(circle.Draw());
            Console.WriteLine(circle.CalculatePerimeter());
            Console.WriteLine(circle.CalculateArea());
            double height = double.Parse(Console.ReadLine());
            double width = double.Parse(Console.ReadLine());
            Rectangle rect = new Rectangle(height, width);
            Console.WriteLine(rect.Draw());
            Console.WriteLine(rect.CalculatePerimeter());
            Console.WriteLine(rect.CalculateArea());
        }
    }
}