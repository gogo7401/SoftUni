﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace _05_Football_Team_Generator
{
    public class Team
    {
        private string name;

        private Player player;

        

        public Team(string name)
        {
            Name = name;
            players =  new List<Player>();
        }

        public readonly List<Player> players;

        public string Name 
        { 
            get { return name; }
            private set
            {
                if (string.IsNullOrEmpty(value) || string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("A name should not be empty.");
                }
                name = value;
            }
        }

        public int Rating
        {
            get 
            {   if (players.Count == 0) { return 0; }
                double average = players.Average(p => p.SkillLevel);
                double result = Math.Round(average, 0, MidpointRounding.AwayFromZero);
                return (int) result;
            }
        }

        public void Add(Player player)
        {
            players.Add(player);    
        }

        public void Remove(string playerName)
        {
            Player player = players.FirstOrDefault(p => p.Name == playerName);

            if (player == null)
            {
                throw new ArgumentException($"Player {playerName} is not in {Name} team.");
            }

            players.Remove(player);
        }

  
    }
}
