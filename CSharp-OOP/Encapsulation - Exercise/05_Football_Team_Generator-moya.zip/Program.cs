﻿namespace _05_Football_Team_Generator
{
    public class Program
    {
        static void Main(string[] args)
        {
            //string[] teamInfo = Console.ReadLine().Split(";", StringSplitOptions.RemoveEmptyEntries);
            //Team team = new Team(teamInfo[1]);
            List<Team> teams = new(); 

            string input = string.Empty;
            while ((input = Console.ReadLine()) != "END")
            {
                string[] tokens = input.Split(";", StringSplitOptions.RemoveEmptyEntries);
                string command = tokens[0];
                string teamName = tokens[1];
                string playerName = string.Empty;

                switch (command)
                {
                    case "Team":
                        teams.Add(new Team(teamName));
                        break;

                    case "Add":
                        playerName = tokens[2];
                        int endurance = int.Parse(tokens[3]);
                        int sprint = int.Parse(tokens[4]);
                        int dribble = int.Parse(tokens[5]);
                        int passing = int.Parse(tokens[6]);
                        int shooting = int.Parse(tokens[7]);
                        try
                        {
                            Team team = teams.FirstOrDefault(p => p.Name == teamName);

                            if (team == null)
                            {
                                Console.WriteLine($"Team {teamName} does not exist.");

                                return;
                            }

                            Player player = new Player(playerName, endurance,sprint,dribble,passing, shooting);
                            team.Add(player);
                        }
                        catch (Exception e)
                        {

                            Console.WriteLine(e.Message);
                        }

                        break;

                    case "Remove":
                        playerName = tokens[2];

                        try
                        {
                            Team team = teams.FirstOrDefault(p => p.Name == teamName);

                            if (team == null)
                            {
                                Console.WriteLine($"Team {teamName} does not exist.");

                                return;
                            }


                            team.Remove(playerName);
                        }
                        catch (Exception e)
                        {

                            Console.WriteLine(e.Message);
                        }

                        break;

                    case "Rating":

                        try
                        {
                            Team team = teams.FirstOrDefault(p => p.Name == teamName);

                            if (team == null)
                            {
                                Console.WriteLine($"Team {teamName} does not exist.");
                                return;
                            }
                            else
                            {

                            Console.WriteLine($"{team.Name} - {team.Rating}");
                            }
 
                        }
                        catch (Exception e)
                        {

                            Console.WriteLine(e.Message);
                        }

                        break;

                }



            }

            //try
            //{
            //    Player player = new Player("Ivan", 75, 85, 84, 92, 67);
            //    team.Add("Arsenal", player);

            //    Console.WriteLine($"{team.Name} - {team.TeamRating}");

            //    team.Remove("Arsenal", "Ivan");
            //    Console.WriteLine("Remove");
            //    //team.Remove("Arsenal", "Ivan");
            //    Console.WriteLine(team.Rating("wer"));

            //}
            //catch (Exception e)
            //{

            //    Console.WriteLine(e.Message); 
            //}

            //Console.WriteLine($"{team.Name} - {team.TeamRating}");
            
            ////Console.WriteLine(player.SkillLevel);


        }
    }
}