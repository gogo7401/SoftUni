﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Shopping_Spree
{
    public class Person
    {
        private List<Person> people;
        private List<string> bag;
        private decimal money;

        public string Name { get; set; }

        public decimal Money
        {
            get { return money; }
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException("Money cannot be negative");
                }
                money = value;
            }
        }

        public List<string> Bag { get { return bag; } set { bag = value; } }

        public List<Person> People { get; set; }

        public Person()
        {
            people = new List<Person>();
            bag = new List<string>();
        }

        public void AddPerson(string name, decimal money)
        {
            people.Add(new Person { Name = name, Money = money, Bag = new List<string>() });
        }

        public string BuyProduct(string personName, string productName, decimal price)
        {

            string result = string.Empty;




            foreach (var person in people)
            {
                if (person.Name == personName && person.Money >= price)
                {
                    result = $"{personName} bought {productName}";
                    person.Money -= price;
                    person.bag.Add(productName);            //.Bag.Add(productName);
                    return result;
                }
            }


            return $"{personName} can't afford {productName}";
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            foreach (var person in people)
            {
                if (person.Bag.Count == 0)
                {
                    sb.AppendLine($"{person.Name} - Nothing bought");
                }
                else
                {

                    sb.AppendLine($"{person.Name} - {string.Join(", ", person.Bag)}");
                }

            }

            return sb.ToString();
        }

    }
}
