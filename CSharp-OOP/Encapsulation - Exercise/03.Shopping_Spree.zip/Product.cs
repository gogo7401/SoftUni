﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopping_Spree
{
    public class Product
    {
        private string name;
        private decimal cost;
        private Dictionary<string, decimal> products;

        public Product()//string name, decimal cost)
        {
            //Name = name;
            //Cost = cost;
            products = new Dictionary<string, decimal>();
        }


        public Product(string name)
        {
            
        }

        public Dictionary<string, decimal> Products { get; set; }

        public string Name 
        { get { return name; }
            private set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("Name cannot be empty");
                }
                name = value;
            }
        }
        public decimal Cost 
        { get { return cost; } 
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException("Money cannot be negative");
                }
                cost = value;
            }
        }   

        public void AddProduct(string name, decimal cost)
        {
            if (!products.ContainsKey(name))
            {
                products.Add(name, cost);   
            }
            products[name] = cost;

            Products = products;
        }

        public decimal GetPriceProduct(string name)
        {
            return products[name];
        }

    }
}
