﻿namespace Shopping_Spree
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person person = new Person();

            Product product = new Product();

            string[] lineOne = Console.ReadLine().Split(";", StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < lineOne.Length; i++)
            {
                string[] tokens = lineOne[i].Split("=", StringSplitOptions.RemoveEmptyEntries);
                try
                {
                    person.AddPerson(tokens[0], decimal.Parse(tokens[1]));

                }
                catch (Exception e)
                {

                    Console.WriteLine(e.Message);
                    return;
                }
            }

            string[] lineTwo = Console.ReadLine().Split(";", StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < lineTwo.Length; i++)
            {
                string[] tokens = lineTwo[i].Split("=", StringSplitOptions.RemoveEmptyEntries);
                try
                {

                    product.AddProduct(tokens[0], decimal.Parse(tokens[1]));
                }
                catch (Exception e)
                {

                    Console.WriteLine(e.Message);
                    return;
                }
            }


            string input = string.Empty;

            while ((input = Console.ReadLine()) != "END")
            {
                string[] tokens = input.Split(" ", StringSplitOptions.RemoveEmptyEntries);

                if (product.Products.ContainsKey(tokens[1]))
                {
                    decimal price = product.GetPriceProduct(tokens[1]);
                    Console.WriteLine(person.BuyProduct(tokens[0], tokens[1], price));

                }




            }

            Console.WriteLine(person.ToString());

        }
    }
}