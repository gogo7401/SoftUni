﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_Pizza_Calories
{
    public static class ExceptionMessages
    {
        public const string TypeOrBakingExceptionMessage = "Invalid type of dough.";
        public const string DoughWeighExeptionMessage = "Dough weight should be in the range [1..200].";
    }
}
