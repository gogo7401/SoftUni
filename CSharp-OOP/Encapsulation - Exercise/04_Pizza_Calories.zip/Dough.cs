﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_Pizza_Calories
{
    public class Dough
    {
        private const double BASE_MODIFIER = 2.0;
        //private const double WHITE_MODIFIER = 1.5;
        //private const double WHOLEGRAIN_MODIFIER = 1.0;
        //private const double CRISPY_MODIFIER = 0.9;
        //private const double CHEWY_MODIFIER = 1.1;
        //private const double HOMEMADE_MODIFIER = 1.0;
        private const string TYPE_FLOUR = "WHITE, WHOLEGRAIN";
        private const string BAKING_TECHNIQUE = "CRISPY, CHEWY, HOMEMADE";
        private const int MIN_WEIGH = 1;
        private const int MAX_WEIGH = 200;


        private string flourType;
        private string bakingTechnique;
        private int weigh;
        private Dictionary<string, double> modifiers;


        public Dough(string flourType, string bakingTechnique, int weigh)
        {
            FlourType = flourType;
            BakingTechnique = bakingTechnique;
            Weigh = weigh;
            modifiers = new Dictionary<string, double>()
            {
                { "WHITE", 1.5 },
                { "WHOLEGRAIN", 1.0 }, 
                { "CRISPY", 0.9 },
                { "CHEWY", 1.1 },
                { "HOMEMADE", 1.0 }
            };
        }

        public string FlourType 
        { 
            get { return flourType; } 
            set 
            { 
                if (!TYPE_FLOUR.Contains(value.ToUpper()))
                {
                    throw new ArgumentException(ExceptionMessages.TypeOrBakingExceptionMessage);
                }
                flourType = value; 
            }
        }
        public string BakingTechnique 
        {
            get { return bakingTechnique; } 
            set 
            {
                if (!BAKING_TECHNIQUE.Contains(value.ToUpper()))
                {
                    throw new ArgumentException(ExceptionMessages.TypeOrBakingExceptionMessage);
                }
                bakingTechnique = value; 
            }
        }

        public int Weigh 
        {
            get { return weigh; } 
            set
            {
                if (value < MIN_WEIGH || value > MAX_WEIGH)
                {
                    throw new ArgumentException(ExceptionMessages.DoughWeighExeptionMessage);
                }
                weigh = value;
            } 
        }

        public double CaloriesCalculate(Dough dough) //(string type, string technique, int grams)
        {
            double calories = 0.0;
            calories = BASE_MODIFIER * dough.Weigh * modifiers[dough.FlourType.ToUpper()] * modifiers[dough.BakingTechnique.ToUpper()];


            return calories;
        }

    }
}
