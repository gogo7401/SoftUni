﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_Pizza_Calories
{
    public class Topping
    {
        private const double BASE_MODIFIER = 2.0;
        private const string TYPE_TOPPING = "MEAT, VEGGIES, CHEESE, SAUCE";
        private const int MIN_WEIGH = 1;
        private const int MAX_WEIGH = 50;


        private string toppingType;
        private int weigh;
        private Dictionary<string, double> modifiers;

        public Topping(string toppingType, int weigh)
        {
            ToppingType = toppingType;
            Weigh = weigh;
            modifiers = new Dictionary<string, double>()
            {
                { "MEAT", 1.2 },
                { "VEGGIES", 0.8 },
                { "CHEESE", 1.1 },
                { "SAUCE", 0.9 }
            };
        }

        public string ToppingType
        {
            get { return toppingType; }
            set
            {
                if (!TYPE_TOPPING.Contains(value.ToUpper()))
                {
                    throw new ArgumentException($"Cannot place {value} on top of your pizza.");
                }
                toppingType = value;
            }
        }

        public int Weigh
        {
            get { return weigh; }
            set
            {
                if (value < MIN_WEIGH || value > MAX_WEIGH)
                {
                    throw new ArgumentException($"{toppingType} weight should be in the range [1..50].");
                }
                weigh = value;
            }
        }

        public double CaloriesCalculate(Topping topping) 
        {
            double calories = 0.0;
            calories = BASE_MODIFIER * topping.Weigh * modifiers[topping.ToppingType.ToUpper()];


            return calories;
        }

    }
}
