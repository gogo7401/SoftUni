﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_Pizza_Calories
{
    public class Pizza
    {
		private string name;
        private int numberOfToppings;
        private double totalCalories;
        private Dough dough;
		private Topping topping;




        public string Name
		{
			get { return name; }
			set 
			{
				if (value.Length > 15 || value.Length <= 0)
				{
					throw new ArgumentException("Pizza name should be between 1 and 15 symbols.");
				}
				name = value; 
			}
		}

		public int NumberOfToppings
        {
			get { return numberOfToppings; }
			set 
			{ 
				if (value > 10)
				{
					throw new ArgumentException("Number of toppings should be in range [0..10].");
				}
				numberOfToppings = value; 
			}
		}

		public double TotalCalories
		{
			get { return totalCalories; }
			set { totalCalories = value; }
		}

		public Dough Dough 
		{ 
			get; 
			set; 
		}
		public Topping Topping 
		{ 
			get; 
			set; 
		}	

		public void AddTopping(double calories)
		{
			NumberOfToppings++;
			totalCalories +=calories;
        }

        public void AddDough(double calories)
        {
            totalCalories += calories;
        }


    }
}
