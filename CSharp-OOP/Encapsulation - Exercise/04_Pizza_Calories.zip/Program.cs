﻿namespace _04_Pizza_Calories
{
    public class Program
    {
        static void Main(string[] args)
        {
            string input = string.Empty;
            string type = string.Empty;    
            string technique = string.Empty;
            int grams = 0;
            Pizza pizza = new Pizza();

            while ((input = Console.ReadLine()) != "END")
            {
                string[] tokens = input.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string ingredient = tokens[0];
                try
                {
                    switch (ingredient)
                    {
                        case "Dough":

                            type = tokens[1];
                            technique = tokens[2];
                            grams = int.Parse(tokens[3]);
                            Dough dough = new Dough(type, technique, grams);
                            //Console.WriteLine(dough.CaloriesCalculate(dough).ToString("F2"));
                            pizza.AddDough(dough.CaloriesCalculate(dough));
                            break;

                        case "Topping":

                            type = tokens[1];
                            grams = int.Parse(tokens[2]);
                            Topping topping = new Topping(type, grams);
                            //Console.WriteLine(topping.CaloriesCalculate(topping).ToString("F2"));
                            pizza.AddTopping(topping.CaloriesCalculate(topping));
                            break;

                        case "Pizza":

                            if (tokens.Length <= 1)
                            {
                                throw new ArgumentException("Pizza name should be between 1 and 15 symbols.");
                            }
                            pizza.Name = tokens[1];
                            break;

                        default:
                            break;
                    }

                }
                catch (Exception e)
                {

                    Console.WriteLine(e.Message);
                    return;
                }

            }

            Console.WriteLine($"{pizza.Name} - {pizza.TotalCalories.ToString("F2")} Calories.");
        }
    }
}