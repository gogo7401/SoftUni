﻿using _04_Random_List;

namespace CustomRandomList
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            RandomList list = new RandomList();

            for (int i = 0; i < 10; i++)
            {
                list.Add(i.ToString());
            }

            Console.WriteLine(list.RandomString());
        }
    }

}