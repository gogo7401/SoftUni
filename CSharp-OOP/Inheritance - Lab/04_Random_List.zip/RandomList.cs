﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_Random_List
{
    public class RandomList : List<string>
    {
        private Random random;

        public RandomList()
        {
            random = new Random();
        }

        public string RandomString()
        {
            int idx = random.Next(0, Count);

            string result = this[idx];

            this.RemoveAt(idx);

            return result;
        }
    }
}
