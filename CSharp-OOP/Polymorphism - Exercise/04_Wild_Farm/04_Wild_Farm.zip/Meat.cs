﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_Wild_Farm
{
    internal class Meat : Food
    {
        public Meat(int quantity) : base(quantity)
        {
        }
    }
}
