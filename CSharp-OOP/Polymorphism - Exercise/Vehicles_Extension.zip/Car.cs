﻿using System.Reflection.Metadata.Ecma335;

namespace Vehicle
{
    public class Car : Vehicle
    {
        private const double CAR_INCREASE = 0.9;
        public Car(double fuelQuantity, double fuelConsumption, double tankCapacity) : base(fuelQuantity, fuelConsumption, tankCapacity)
        {
        }

        public override string Drive(double distance, bool empty)
        {
            string message = string.Empty;

            double consumption = distance * (CAR_INCREASE + FuelConsumption);

            if (consumption <= FuelQuantity)
            {
                message = $"{GetType().Name} travelled {distance} km";
                FuelQuantity -= consumption;
            }
            else
            {
                message = $"{GetType().Name} needs refueling";
            }

            return message;
        }

        public override void Refuel(double refuel)
        {
            base.Refuel(refuel);
        }

        public override string ToString()
        {
            return $"Car: {FuelQuantity:F2}";
        }
    }
}
