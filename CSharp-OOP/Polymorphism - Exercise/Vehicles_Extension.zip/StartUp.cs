﻿namespace Vehicle
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Vehicle car = null;
            Vehicle truck = null;
            Vehicle bus = null;

            for (int i = 0; i < 3; i++)
            {
                string[] vehicleInfo = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                if (vehicleInfo[0] == "Car")
                {
                    car = new Car(double.Parse(vehicleInfo[1]), double.Parse(vehicleInfo[2]), double.Parse(vehicleInfo[3]));
                }
                else if (vehicleInfo[0] == "Truck")
                {
                    truck = new Truck(double.Parse(vehicleInfo[1]), double.Parse(vehicleInfo[2]), double.Parse(vehicleInfo[3]));
                }
                else if (vehicleInfo[0] == "Bus")
                {
                    bus = new Bus(double.Parse(vehicleInfo[1]), double.Parse(vehicleInfo[2]), double.Parse(vehicleInfo[3]));
                }
            }

            int countOperation = int.Parse(Console.ReadLine());

            for (int i = 0; i < countOperation; i++)
            {
                string[] vehicleInfo = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string action = vehicleInfo[0];
                string typeVehicle = vehicleInfo[1];

                if (action == "Drive")
                {
                    if (typeVehicle == "Car")
                    {
                        Console.WriteLine(car.Drive(double.Parse(vehicleInfo[2]),true));
                    }
                    else if (typeVehicle == "Truck")
                    {
                        Console.WriteLine(truck.Drive(double.Parse(vehicleInfo[2]),true));
                    }
                    else if (typeVehicle == "Bus")
                    {
                        Console.WriteLine(bus.Drive(double.Parse(vehicleInfo[2]), false));
                    }
                }
                else if (action == "DriveEmpty" && typeVehicle == "Bus")
                {
                    Console.WriteLine(bus.Drive(double.Parse(vehicleInfo[2]), true));
                }
                else if (action == "Refuel")
                {
                    if (typeVehicle == "Car")
                    {
                        car.Refuel(double.Parse(vehicleInfo[2]));
                    }
                    else
                    {
                        truck.Refuel(double.Parse(vehicleInfo[2]));
                    }
                }

            }

            Console.WriteLine(car.ToString());
            Console.WriteLine(truck.ToString());
            Console.WriteLine(bus.ToString());
        }
    }
}