﻿namespace Vehicle
{
    public class Bus : Vehicle
    {
        private double fuelIncrement = 0;

        public Bus(double fuelQuantity, double fuelConsumption, double tankCapacity) : base(fuelQuantity, fuelConsumption, tankCapacity)
        {
        }

        public override string Drive(double distance, bool empty)
        {
            if (!empty)
            {
                fuelIncrement = 1.4;
            }

            string message = string.Empty;

            double consumption = distance * (fuelIncrement + FuelConsumption);

            if (consumption <= FuelQuantity)
            {
                message = $"{GetType().Name} travelled {distance} km";
                FuelQuantity -= consumption;
            }
            else
            {
                message = $"{GetType().Name} needs refueling";
            }

            return message;
        }

        public override void Refuel(double refuel)
        {
            base.Refuel(refuel);
        }

        public override string ToString()
        {
            return $"Bus: {FuelQuantity:F2}";
        }
    }
}
