﻿namespace Vehicle
{
    public class Truck : Vehicle
    {
        private const double TRUCK_INCREASE = 1.6;

        public Truck(double fuelQuantity, double fuelConsumption, double tankCapacity) : base(fuelQuantity, fuelConsumption, tankCapacity)
        {
            
        }

        public override string Drive(double distance, bool empty)
        {
            string message = string.Empty;

            double consumption = distance * (TRUCK_INCREASE + FuelConsumption);

            if (consumption <= FuelQuantity)
            {
                message = $"{GetType().Name} travelled {distance} km";
                FuelQuantity -= consumption;
            }
            else
            {
                message = $"{GetType().Name} needs refueling";
            }

            return message;
        }

        public override void Refuel(double refuel)
        {
            base.Refuel(refuel);
        }

        public override string ToString()
        {
            return $"Truck: {FuelQuantity:F2}";
            
        }
    }
}
