﻿namespace Vehicle
{
    public abstract class Vehicle
    {
        private double fuelQuantity;

        public Vehicle(double fuelQuantity, double fuelConsumption, double tankCapacity)
        {
            TankCapacity = tankCapacity;
            this.FuelQuantity = fuelQuantity;
            FuelConsumption = fuelConsumption;
        }

        protected double FuelQuantity 
        { 
            get { return fuelQuantity; }
            set
            {
                if (value <= TankCapacity)
                {
                    fuelQuantity = value;

                }
                else
                {
                    fuelQuantity = 0;
                }
            }
        }
        protected double FuelConsumption { get; set; }
        protected double TankCapacity { get; set; }

        public abstract string Drive(double distance, bool empty);


        public virtual void Refuel(double refuel)
        {
            if (refuel <= 0)
            {
                Console.WriteLine("Fuel must be a positive number");

            }
            else if (refuel > TankCapacity)
            {
                Console.WriteLine($"Cannot fit {refuel} fuel in the tank");
            }
            else
            {
                if (this.GetType().Name == "Truck")
                {
                    refuel = refuel * 0.95;
                }
                FuelQuantity += refuel;
            }
        }

      

    }
}
