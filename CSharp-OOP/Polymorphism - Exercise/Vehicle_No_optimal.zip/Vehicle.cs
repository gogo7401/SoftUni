﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicle
{
    public abstract class Vehicle
    {
        private const double CAR_INCREASE = 0.9;

        private const double TRUCK_INCREASE = 1.6;

        public Vehicle(double fuelQuantity, double fuelConsumption)
        {
            FuelQuantity = fuelQuantity;
            FuelConsumption = fuelConsumption;
        }

        protected double FuelQuantity { get; set; }
        protected double FuelConsumption { get; set; }

        public string Drive(double distance)
        {
            string message = string.Empty;
            double addConsumption = 0;

            if (GetType().Name == "Car")
            {
                addConsumption = CAR_INCREASE;
            }
            else
            {
                addConsumption = TRUCK_INCREASE;
            }

            double consumption = distance * (addConsumption + FuelConsumption);

            if (consumption <= FuelQuantity)
            {
                message = $"{GetType().Name} travelled {distance} km";
                FuelQuantity -= consumption;
            }
            else
            {
                message = $"{GetType().Name} needs refueling";
            }

            return message;
        }

        public abstract void Refuel(double refuel);
      

    }
}
