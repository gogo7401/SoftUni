﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicle
{
    public class Truck : Vehicle
    {
        public Truck(double fuelQuantity, double fuelConsumption) : base(fuelQuantity, fuelConsumption)
        {
        }

        public override void Refuel(double refuel)
        {
            FuelQuantity += refuel*0.95;
        }

        public override string ToString()
        {
            return $"Truck: {FuelQuantity:F2}";
            //return $"Truck: {Math.Round(FuelQuantity, 2, MidpointRounding.AwayFromZero)}";
        }
    }
}
