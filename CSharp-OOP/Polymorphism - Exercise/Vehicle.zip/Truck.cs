﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicle
{
    public class Truck : Vehicle
    {
        private const double TRUCK_INCREASE = 1.6;

        public Truck(double fuelQuantity, double fuelConsumption) : base(fuelQuantity, fuelConsumption)
        {
            
        }

        public override string Drive(double distance)
        {
            string message = string.Empty;

            double consumption = distance * (TRUCK_INCREASE + FuelConsumption);

            if (consumption <= FuelQuantity)
            {
                message = $"{GetType().Name} travelled {distance} km";
                FuelQuantity -= consumption;
            }
            else
            {
                message = $"{GetType().Name} needs refueling";
            }

            return message;
        }

        public override void Refuel(double refuel)
        {
            FuelQuantity += refuel*0.95;
        }

        public override string ToString()
        {
            return $"Truck: {FuelQuantity:F2}";
            //return $"Truck: {Math.Round(FuelQuantity, 2, MidpointRounding.AwayFromZero)}";
        }
    }
}
