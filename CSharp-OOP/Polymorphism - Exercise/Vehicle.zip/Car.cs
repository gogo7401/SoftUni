﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicle
{
    public class Car : Vehicle
    {
        private const double CAR_INCREASE = 0.9;
        public Car(double fuelQuantity, double fuelConsumption) : base(fuelQuantity, fuelConsumption)
        {
        }

        public override string Drive(double distance)
        {
            string message = string.Empty;
           
            double consumption = distance * (CAR_INCREASE + FuelConsumption);

            if (consumption <= FuelQuantity)
            {
                message = $"{GetType().Name} travelled {distance} km";
                FuelQuantity -= consumption;
            }
            else
            {
                message = $"{GetType().Name} needs refueling";
            }

            return message;
        }

        public override void Refuel(double refuel)
        {
            FuelQuantity += refuel;
        }

        public override string ToString()
        {
            return $"Car: {FuelQuantity:F2}";
        }
    }
}
