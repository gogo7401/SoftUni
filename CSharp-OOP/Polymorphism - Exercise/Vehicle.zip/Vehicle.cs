﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicle
{
    public abstract class Vehicle
    {

        public Vehicle(double fuelQuantity, double fuelConsumption)
        {
            FuelQuantity = fuelQuantity;
            FuelConsumption = fuelConsumption;
        }

        protected double FuelQuantity { get; set; }
        protected double FuelConsumption { get; set; }

        public abstract string Drive(double distance);
        

        public abstract void Refuel(double refuel);
      

    }
}
