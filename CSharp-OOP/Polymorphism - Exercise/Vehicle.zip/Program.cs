﻿namespace Vehicle
{
    public class Program
    {
        static void Main(string[] args)
        {
            Vehicle car = null;
            Vehicle truck = null;
            for (int i = 0; i < 2; i++)
            {
                string[] vehicleInfo = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                if (vehicleInfo[0] == "Car")
                {
                    car = new Car(double.Parse(vehicleInfo[1]), double.Parse(vehicleInfo[2]));
                }
                else if (vehicleInfo[0] == "Truck")
                {
                    truck = new Truck(double.Parse(vehicleInfo[1]), double.Parse(vehicleInfo[2]));
                }
            }

            int countOperation = int.Parse(Console.ReadLine());

            for (int i = 0; i < countOperation; i++)
            {
                string[] vehicleInfo = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string action = vehicleInfo[0];
                string typeVehicle = vehicleInfo[1];

                if (action == "Drive")
                {
                    if (typeVehicle == "Car")
                    {
                        Console.WriteLine(car.Drive(double.Parse(vehicleInfo[2])));
                    }
                    else
                    {
                        Console.WriteLine(truck.Drive(double.Parse(vehicleInfo[2])));
                    }
                }
                else if (action == "Refuel")
                {
                    if (typeVehicle == "Car")
                    {
                        car.Refuel(double.Parse(vehicleInfo[2]));
                    }
                    else
                    {
                        truck.Refuel(double.Parse(vehicleInfo[2]));
                    }
                }

            }

            Console.WriteLine(car.ToString());
            Console.WriteLine(truck.ToString());




            //Vehicle car = new Car(15, 0.3);
            //Console.WriteLine(car.Drive(50));
            //Console.WriteLine(car.ToString());
        }
    }
}