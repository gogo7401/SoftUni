using NUnit.Framework;

[TestFixture]
public class AxeTests
{
    [Test]
    public void Test1()
    {

    }
}