﻿namespace _09_Explicit_Interfaces
{
    public class Program
    {
        static void Main(string[] args)
        {
            string input = string.Empty;

            while ((input = Console.ReadLine()) != "End")
            {
                string[] tokens = input.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                Citizen citizen = new Citizen(tokens[0], tokens[1], int.Parse(tokens[2]));
                IPerson person = citizen;
                IResident resident = citizen;
                person.GetName();
                resident.GetName();
                

            }
        }
    }
}