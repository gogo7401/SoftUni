﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _08_Collection_Hierarchy
{
    public class AddRemoveCollection : Collection, IAddRemoveCollection
    {
        public int Add(string item)
        {
            list.Insert(0, item);
            return list.IndexOf(item);
        }

        public string Remove()
        {
            string lastItem = null;
            if (list.Count > 0)
            {
                lastItem = list[list.Count - 1];
                list.RemoveAt(list.Count - 1);
            }
                return lastItem;
            
        }
    }
}
