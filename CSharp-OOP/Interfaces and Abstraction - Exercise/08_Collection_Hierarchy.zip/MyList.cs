﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _08_Collection_Hierarchy
{
    public class MyList : Collection, IMyList
    {
        //public int Used => list.Count;

        //public int Add(string item)
        //{
        //    list.Insert(0, item);
        //    return list.IndexOf(item);
        //}

        //public string Remove()
        //{
        //    string firstItem = null;
        //    if (list.Count > 0)
        //    {
        //        firstItem = list[0];
        //        list.RemoveAt(0);

        //    }
        //    return firstItem;
        //}

        //public class MyList : IMyList
        //{
            private const int AddIndex = 0;
            private const int RemoveIndex = 0;

            private readonly List<string> data;

            public MyList()
            {
                data = new List<string>();
            }

            public int Used => data.Count;

            public int Add(string item)
            {
                data.Insert(AddIndex, item);

                return AddIndex;
            }

            public string Remove()
            {
                string item = data[RemoveIndex];

                data.RemoveAt(RemoveIndex);

                return item;
            }
        //}
    }
}
