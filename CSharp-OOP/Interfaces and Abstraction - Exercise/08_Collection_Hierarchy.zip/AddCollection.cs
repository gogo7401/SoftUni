﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _08_Collection_Hierarchy
{
    public class AddCollection : Collection, IAddCollection

    {

        public int Add(string item)
        {
            list.Add(item);
            return list.IndexOf(item);
        }
    }
}
