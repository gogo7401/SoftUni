﻿using System.Text;

namespace _08_Collection_Hierarchy
{
    public class Program
    {
        static void Main(string[] args)
        {
            //List<ICollection> collections = new List<ICollection>();

            //string[] lineOne = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            //int removeCount = int.Parse(Console.ReadLine());
            //AddCollection addCollection = new AddCollection();
            //AddRemoveCollection removeCollection = new AddRemoveCollection();
            //MyList myList = new MyList();
            //int[,] place = new int[3, lineOne.Length];
            //int i = 0;
            //int j = -1;
            //foreach (string item in lineOne)
            //{
            //    i = 0;
            //    j++;
            //    place[i, j] = addCollection.Add(item);
            //    i++;
            //    //Console.Write(addCollection.Add(item) + " ");
            //    place[i, j] = removeCollection.Add(item);
            //    i++;
            //    place[i, j] = myList.Add(item);

            //}

            //for (int ii = 0; ii < 3; ii++)
            //{
            //    for (int jj = 0; jj < lineOne.Length; jj++)
            //    {
            //        Console.Write(place[ii, jj] + " ");
            //    }
            //    //if (ii != 2)
            //    //{
            //        Console.WriteLine();
            //    //}
            //}


            //for (int rc = 0; rc < removeCount; rc++)
            //{
            //    Console.Write(removeCollection.Remove() + " ");
            //}
            //Console.WriteLine();
            //for (int rc = 0;rc < removeCount; rc++) 
            //{
            //    Console.Write(myList.Remove() + " ");
            //}

            Dictionary<string, List<int>> addedIndexes = new()
            {
                { "AddCollection", new List<int>() },
                { "AddRemoveCollection", new List<int>() },
                { "MyList", new List<int>() }
            };

            Dictionary<string, List<string>> removedItems = new()
            {
                { "AddCollection", new List<string>() },
                { "AddRemoveCollection", new List<string>() },
                { "MyList", new List<string>() }
            };

            IAddCollection addCollection = new AddCollection();
            IAddRemoveCollection addRemoveCollection = new AddRemoveCollection();
            IMyList myList = new MyList();

            string[] items = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

            foreach (var item in items)
            {
                addedIndexes["AddCollection"].Add(addCollection.Add(item));

                addedIndexes["AddRemoveCollection"].Add(addRemoveCollection.Add(item));

                addedIndexes["MyList"].Add(myList.Add(item));
            }

            int removeCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < removeCount; i++)
            {
                removedItems["AddRemoveCollection"].Add(addRemoveCollection.Remove());
                removedItems["MyList"].Add(myList.Remove());
            }

            Console.WriteLine(string.Join(" ", addedIndexes["AddCollection"]));
            Console.WriteLine(string.Join(" ", addedIndexes["AddRemoveCollection"]));
            Console.WriteLine(string.Join(" ", addedIndexes["MyList"]));

            Console.WriteLine(string.Join(" ", removedItems["AddRemoveCollection"]));
            Console.WriteLine(string.Join(" ", removedItems["MyList"]));

        }
    }
}