﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03_Telephony
{
    public class StationaryPhone : IStationaryPhone
    {
        private string number;

        public StationaryPhone(string number)
        {
            this.number = number;
        }

        public void Call()
        {
            if (number.Length == 7)
            {
                Console.WriteLine($"Dialing... {number}");
            }
        }
    }
}
