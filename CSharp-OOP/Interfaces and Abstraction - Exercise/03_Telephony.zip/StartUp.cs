﻿namespace _03_Telephony
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<Smartphone> listSmartphones = new List<Smartphone>();
            List<StationaryPhone> listStationaryPhones = new List<StationaryPhone>();


            string[] lineOne = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);


            for (int i = 0; i < lineOne.Length; i++)
            {
                if (!long.TryParse(lineOne[i], out long temp))
                {
                    Console.WriteLine("Invalid number!");
                    continue;
                }
                IStationaryPhone phone = new StationaryPhone(lineOne[i]);
                phone.Call();
                ISmartphone smartPhone = new Smartphone(lineOne[i]);
                smartPhone.Call();
            }

            // Any(letter => char.IsDigit(letter));

            string[] lineTwo = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < lineTwo.Length; i++)
            {
                if (lineTwo[i].Any(letter => char.IsDigit(letter)))
                {
                    Console.WriteLine("Invalid URL!");
                    continue;
                }

                ISmartphone smartPhone = new Smartphone(lineTwo[i], true);
                smartPhone.Browse();
            }


        }
    }
}