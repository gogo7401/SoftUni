﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03_Telephony
{
    public class Smartphone : ISmartphone
    {
        private string number;
        private string url;

        public Smartphone(string number)
        {
            this.number = number;
        }

        public Smartphone(string url, bool none)
        {
            this.url = url;
        }

        public void Browse()
        {
            Console.WriteLine($"Browsing: {url}!");
        }

        public void Call()
        {
            if (number.Length == 10)
            {
                Console.WriteLine($"Calling... {number}");
            }
        }
    }
}
