﻿namespace _04_Border_Control
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<IPrintable> printables = new List<IPrintable>();
            
            string input = string.Empty;

            while ((input = Console.ReadLine()) != "End")
            {
                string[] tokens = input.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                if (tokens.Length == 2)
                {
                    printables.Add(new Robot(tokens[0], tokens[1]));    
                }
                else if (tokens.Length == 3)
                {
                    printables.Add(new Citizen(tokens[0], int.Parse(tokens[1]), tokens[2]));
                }

            }

            string lastDigits = Console.ReadLine();
            Detained detained = new Detained(printables, lastDigits);
            detained.PrintDetained();
        }
    }
}