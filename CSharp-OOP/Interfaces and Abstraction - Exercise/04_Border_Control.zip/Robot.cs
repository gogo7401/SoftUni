﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_Border_Control
{
    public class Robot : IPrintable
    {
        public Robot(string model, string id)
        {
            Model = model;
            Id = id;
        }

        public string Model { get; }

        public string Id { get; }


        public void PrintIDs()
        {
            Console.WriteLine(Id);
        }
    }
}
