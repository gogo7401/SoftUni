﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_Border_Control
{
    public class Detained 
    {
        private List<IPrintable> printables;
        private string digitsOfFakeIds;

        public Detained(List<IPrintable> printables, string digitsOfFakeIds)
        {
            this.printables = printables;
            this.digitsOfFakeIds = digitsOfFakeIds;
        }

        public void PrintDetained()
        {
            int digitsCount = digitsOfFakeIds.Length;
            foreach (IPrintable item in printables)
            {
                int itemIdLength = item.Id.Length;
                if (item.Id.Substring((itemIdLength - digitsCount), digitsCount) == digitsOfFakeIds)
                {
                    item.PrintIDs();
                }
            }
        }
        
    }
}
