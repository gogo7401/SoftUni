﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace _05_Birthday_Celebrations
{
    public class Citizen : IBirthday
    {
        public Citizen(string name, int age, string id, string birthday)
        {
            Name = name;
            Age = age;
            Id = id;
            Birthday = birthday;
        }

        public string Name { get; }
        public int Age { get; }
        public string Id { get; }
        public string Birthday { get; }

        public override string ToString()
        {
            return Birthday;
        }
    }
}
