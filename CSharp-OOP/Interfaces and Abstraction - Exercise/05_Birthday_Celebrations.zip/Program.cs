﻿using System.Buffers;

namespace _05_Birthday_Celebrations
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<IBirthday> birthdays = new List<IBirthday>();

            string input = string.Empty;

            while ((input = Console.ReadLine()) != "End")
            {
                string[] tokens = input.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                if (tokens[0] == "Citizen")
                {
                    birthdays.Add(new Citizen(tokens[1], int.Parse(tokens[2]), tokens[3], tokens[4]));
                }
                else if (tokens[0] == "Pet")
                {
                    birthdays.Add(new Pet(tokens[1], tokens[2]));
                }

            }

            string year = Console.ReadLine();

            foreach (IBirthday item in birthdays)
            {
                if (item.Birthday.EndsWith(year))
                {
                    Console.WriteLine(item.ToString());
                }
            }
            
        }
    }
}