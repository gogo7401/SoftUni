﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05_Birthday_Celebrations
{
    public class Pet : IBirthday
    {
        public Pet(string name, string birthday)
        {
            Name = name;
            Birthday = birthday;
        }

        public string Name { get; }
        public string Birthday { get; }

        public override string ToString()
        {
            return Birthday;
        }
    }
}
