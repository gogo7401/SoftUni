﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _07_Military_Elite
{
    public class LeutenantGeneral : ILieutenantGeneral
    {
       // private List<ISoldier> _soldierList;

        public LeutenantGeneral()
        {
            Privates = new List<ISoldier>();
        }

        public LeutenantGeneral(string id, string firstName, string lastName, decimal salary, List<ISoldier> privates) : this()
        {
            Id = id;
            FirstName = firstName;
            LastName = lastName;
            Salary = salary;
            Privates = privates;
        }

        public string Id { get; }
        public string FirstName { get; }
        public string LastName { get; }
        public decimal Salary { get; }
        public List<ISoldier> Privates { get; }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Name: {FirstName} {LastName} Id: {Id} Salary: {Salary:F2}");
            sb.AppendLine("Privates:");
            foreach (var item in Privates)
            {
                sb.AppendLine("  " + item.ToString().TrimEnd());
            }

            return  sb.ToString().TrimEnd();  
        }
    }
}
