﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _07_Military_Elite
{
    public class Engineer : IEngineer
    {
        public Engineer()
        {
            Repairs = new List<string>();
        }
        public Engineer(string id, string firstName, string lastName, decimal salary, string corp, List<string> repairs) : this()
        {
            Id = id;
            FirstName = firstName;
            LastName = lastName;
            Salary = salary;
            Corp = corp;
            Repairs = repairs;
        }

        public string Id { get; }
        public string FirstName { get; }
        public string LastName { get; }
        public decimal Salary { get; }
        public string Corp { get ; }
        public List<string> Repairs { get; }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Name: {FirstName} {LastName} Id: {Id} Salary: {Salary:F2}");
            sb.AppendLine($"Corps: {Corp}");
            sb.AppendLine("Repairs:");
            foreach (var item in Repairs)
            {
                sb.AppendLine("  " + item.ToString());
            }
            
            return sb.ToString().TrimEnd();
        }
    }
}
