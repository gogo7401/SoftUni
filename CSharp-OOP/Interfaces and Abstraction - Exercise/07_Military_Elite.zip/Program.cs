﻿namespace _07_Military_Elite
{
    public class Program
    {
        static void Main(string[] args)
        {
            List<ISoldier> list = new();

            string input = string.Empty;

            while ((input = Console.ReadLine()) != "End")
            {
                string[] tokens = input.Split(" ", StringSplitOptions.RemoveEmptyEntries);

                string soldier = tokens[0];

                if (soldier == "Private")
                {
                    list.Add(new Private(tokens[1], tokens[2], tokens[3], decimal.Parse(tokens[4])));
                }
                else if (soldier == "LieutenantGeneral")
                {
                    List<ISoldier> listPrivates = new List<ISoldier>();

                    for (int i = 5; i < tokens.Length; i++)
                    {
                        ISoldier privateSoldier = list.FirstOrDefault(s => s.Id == tokens[i]);
                        if (privateSoldier != null)
                        {
                            listPrivates.Add(privateSoldier);
                        }
                    }
                    list.Add(new LeutenantGeneral(tokens[1], tokens[2], tokens[3], decimal.Parse(tokens[4]), listPrivates));
                }
                else if (soldier == "Engineer")
                {
                    if (tokens[5] == "Airforces" || tokens[5] == "Marines")
                    {
                        List<string> work = new List<string>();
                        for (int i = 6; i < tokens.Length; i += 2)
                        {
                            work.Add($"Part Name: {tokens[i]} Hours Worked: {tokens[i + 1]}");
                        }
                        list.Add(new Engineer(tokens[1], tokens[2], tokens[3], decimal.Parse(tokens[4]), tokens[5], work));
                    }
                }
                else if (soldier == "Commando")
                {
                    if (tokens[5] == "Airforces" || tokens[5] == "Marines")
                    {
                        List<string> missions = new List<string>();
                        for (int i = 6; i < tokens.Length; i += 2)
                        {
                            if (tokens[i + 1] == "inProgress" || tokens[i + 1] == "Finished")
                            {
                                missions.Add($"Code Name: {tokens[i]} State: {tokens[i + 1]}");
                            }
                        }
                        list.Add(new Commando(tokens[1], tokens[2], tokens[3], decimal.Parse(tokens[4]), tokens[5], missions));
                        Commando com = new Commando();
                        com.CompleteMission();
                    }
                }
                else if (soldier == "Spy")
                {
                    list.Add(new Spy(tokens[1], tokens[2], tokens[3], int.Parse(tokens[4])));
                }
            }

            foreach (ISoldier soldier in list)
            {
                Console.WriteLine(soldier.ToString());
            }
        }
    }
}