﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _07_Military_Elite
{
    public interface ISpecialisedSoldier : IPrivate
    {
        public string Corp { get; }
    }
}
