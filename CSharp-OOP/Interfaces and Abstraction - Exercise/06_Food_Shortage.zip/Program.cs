﻿namespace _06_Food_Shortage
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<IBuyer> list = new List<IBuyer>();
            
            int peopleCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < peopleCount; i++)
            {
                string[] tokens = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

                if (tokens.Length == 4)
                {
                    list.Add(new Citizen(tokens[0], int.Parse(tokens[1]), tokens[2], tokens[3]));
                }
                else
                {
                    list.Add(new Rebel(tokens[0], int.Parse(tokens[1]), tokens[2]));
                }
            }

            string peopleName = string.Empty;

            int totalFood = 0;

            while ((peopleName = Console.ReadLine()) != "End")
            {
                IBuyer buyer = list.FirstOrDefault(name => name.Name == peopleName);

                if (buyer != null)
                {
                    totalFood += buyer.BuyFood();
                }
            }

            Console.WriteLine(totalFood);
        }
    }
}