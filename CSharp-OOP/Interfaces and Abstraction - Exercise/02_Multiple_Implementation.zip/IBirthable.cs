﻿namespace PersonInfo
{
    public interface IBirthable : IPerson
    {
        public string Birthdate { get; }
    }
}
