﻿namespace PersonInfo
{
    public interface IIdentifiable : IPerson
    {
        public string Id { get; }
    }
}
