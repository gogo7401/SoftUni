﻿using System;

namespace Restaurant
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            //Fish fish = new Fish("fish", 5, 5);
            //Console.WriteLine(fish.Grams);

            //Coffee coffee = new Coffee("coffee", 1);
            //Console.WriteLine(coffee.Price);
            //Console.WriteLine(coffee.Caffeine);
        }
    }
}