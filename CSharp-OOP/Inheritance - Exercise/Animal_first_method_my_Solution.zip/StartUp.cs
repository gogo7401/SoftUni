﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Animals
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string animalType = string.Empty;
            string name = string.Empty;
            int age = 0;
            string gender = string.Empty;
            List<Animal> animals = new List<Animal>();  

            while ((animalType = Console.ReadLine()) != "Beast!")
            {
                string[] info = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
                name = info[0];
                age = int.Parse(info[1]);
                gender = info[2];

                if (age <= 0)
                {
                    Console.WriteLine("Invalid input!");
                    continue;
                }

                switch (animalType)
                {
                    case "Dog":
                        Dog dog = new Dog(name, age, gender);
                        animals.Add(dog);
                        break;
                    case "Cat":
                        Cat cat = new Cat(name, age, gender);
                        animals.Add(cat);
                        break;
                    case "Frog":
                        Frog frog = new Frog(name, age, gender);
                        animals.Add(frog);
                        break;
                    case "Kitten":
                        Kitten kitten = new Kitten(name, age);
                        animals.Add((kitten));
                        break;
                    case "Tomcat":
                        Tomcat tomcat = new Tomcat(name, age);
                        animals.Add(tomcat);
                        break;
                }
            }
            Console.WriteLine(string.Join(Environment.NewLine, animals));
        }
    }
}
