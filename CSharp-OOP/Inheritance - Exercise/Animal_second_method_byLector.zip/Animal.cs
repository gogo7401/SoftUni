﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animals
{
    public class Animal
    {
        public Animal(string name, int age, string gender)
        {
            Name = name;
            Age = age;
            Gender = gender;
        }

        private string name;

        public string Name
        {
            get { return name; }
            private set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("Invalid input!");
                }
                name = value;
            }
        }
        private int age;

        public int Age
        {
            get { return age; }
            private set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("Invalid input!");
                }
                age = value;
            }
        }

        private string gender;

        public string Gender
        {
            get { return gender; }
            private set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("Invalid input!");
                }
                gender = value;
            }
        }



        //public string Name { get; set; }
        //public int Age { get; set; }
        //public string Gender { get; set; }

        public virtual string ProduceSound()
        {
            return string.Empty;
        }


        public override string ToString()
        {
            return $"{this.GetType().Name}" + Environment.NewLine +
                   $"{Name} {Age} {Gender}" + Environment.NewLine +
                   $"{ProduceSound()}";
        }
    }
}
