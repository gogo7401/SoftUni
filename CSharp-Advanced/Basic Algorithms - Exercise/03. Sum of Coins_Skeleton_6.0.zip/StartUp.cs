﻿namespace SumOfCoins
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            List<int> coins = Console.ReadLine().Split(", ", StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToList();

            int targetSum = int.Parse(Console.ReadLine());

            Dictionary<int, int> result = new Dictionary<int, int>();

            result = ChooseCoins(coins, targetSum);

            if (result.Count > 0)
            {
                Console.WriteLine($"Number of coins to take: {result.Values.Sum()}");
                foreach (var item in result)
                {
                    Console.WriteLine($"{item.Value} coin(s) with value {item.Key}");
                }
            }
        }

        public static Dictionary<int, int> ChooseCoins(IList<int> coins, int targetSum)
        {
            var result = new Dictionary<int, int>();
            int currentSum = 0;
            int currentIndex = 0;
            int sumByDivade = targetSum;

            // Подреждаме във възходящ ред монетите за да знаем, че почваме от най-голямата към най-малката
            coins = coins.OrderByDescending(x => x).ToArray();

            while (currentSum < targetSum && currentIndex < coins.Count)
            {
                if (currentSum == targetSum)
                {
                    break;
                }

                int divadeCount = sumByDivade / coins[currentIndex];

                if (divadeCount > 0)
                {
                    currentSum += divadeCount * coins[currentIndex];

                    sumByDivade = targetSum - currentSum;

                    result.Add(coins[currentIndex], divadeCount);
                    currentIndex++;
                }
                else
                {
                    currentIndex++; 
                }

            }

            if (currentSum != targetSum)
            {
                //throw new InvalidOperationException("Error");
                Console.WriteLine("Error");
                return new Dictionary<int, int>();
            }

            return result;
        }
    }
}