﻿using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SoftUniKindergarten
{
    public class Kindergarten
    {

        public Kindergarten(string name, int capacity)
        {
            Name = name;
            Capacity = capacity;
            Registry = new List<Child>();
        }

        public string Name { get; }

        public int Capacity { get; }

        public List<Child> Registry { get; }

        public int ChildrenCount { get { return Registry.Count; } }

        public bool AddChild(Child child)
        {
            if (Capacity > Registry.Count && child != null)
            {
                Registry.Add(child);
                return true;
            }
            return false;
        }
        public bool RemoveChild(string childFullName)
        {
            string[] names = childFullName.Split(" ", System.StringSplitOptions.RemoveEmptyEntries);

            return Registry.Remove(Registry.FirstOrDefault(n => n.FirstName == names[0] && n.LastName == names[1]));
        }



        public Child GetChild(string childFullName)
        {
            string[] names = childFullName.Split(" ", System.StringSplitOptions.RemoveEmptyEntries);

            return Registry.FirstOrDefault(n => n.FirstName == names[0] && n.LastName == names[1]);

        }

        public string RegistryReport()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Registered children in {this.Name}:");

            foreach (Child child in Registry.OrderByDescending(x => x.Age).ThenBy(x => x.LastName).ThenBy(x => x.FirstName))
            {
                sb.AppendLine(child.ToString());
            }


            return sb.ToString().TrimEnd();
        }

    }
}
