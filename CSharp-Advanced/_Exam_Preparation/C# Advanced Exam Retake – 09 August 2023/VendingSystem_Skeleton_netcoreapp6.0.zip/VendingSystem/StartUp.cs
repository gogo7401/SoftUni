﻿using System;

namespace VendingSystem
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            
        }
    }
}
