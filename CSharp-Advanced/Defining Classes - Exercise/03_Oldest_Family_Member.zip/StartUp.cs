﻿namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int countPeople = int.Parse(Console.ReadLine());

            Family family = new Family();
            

            for (int i = 0; i < countPeople; i++)
            {
                string[] input = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

                string personName = input[0];
                int personAge = int.Parse(input[1]);

                Person person = new Person(personName, personAge);

                

                family.AddMember(person);

            }
            

            Person oldestPerson = new Person(family.GetOldestMember().Name, family.GetOldestMember().Age);

            Console.WriteLine($"{oldestPerson.Name} {oldestPerson.Age}");

        }
            
    }
}