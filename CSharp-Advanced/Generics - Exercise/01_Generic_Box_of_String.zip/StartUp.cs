﻿namespace _01_Generic_Box_of_String
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int count = int.Parse(Console.ReadLine());

            Box<string> items = new Box<string>();

            for (int i = 0; i < count; i++)
            {
                items.list.Add(Console.ReadLine());
                
            }

            Console.WriteLine(items.ToString());
        }
    }
}