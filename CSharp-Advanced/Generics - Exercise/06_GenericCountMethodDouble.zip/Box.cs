﻿using System.Text;

namespace _06_GenericCountMethodDouble
{
    public class Box<T> where T : IComparable
    {
        public List<T> Items { get; set; }

        public Box()
        {
            Items = new List<T>();
        }

        public int CalculateCount(T itemToCampare)
        {
            int count = 0;  


            foreach (T item in Items)
            {
                if (item.CompareTo(itemToCampare) > 0)
                {
                    count++;
                }
            }

            return count;
        }

    }
}
