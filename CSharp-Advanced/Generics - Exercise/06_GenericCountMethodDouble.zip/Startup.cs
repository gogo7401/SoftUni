﻿namespace _06_GenericCountMethodDouble
{
    public class Startup
    {
        static void Main(string[] args)
        {
            Box<double> list = new Box<double>();

            int numberOfElements = int.Parse(Console.ReadLine());

            for (int i = 0; i < numberOfElements; i++)
            {
                list.Items.Add(double.Parse(Console.ReadLine()));
            }

            Console.WriteLine(list.CalculateCount(double.Parse(Console.ReadLine())));
        }
    }
}