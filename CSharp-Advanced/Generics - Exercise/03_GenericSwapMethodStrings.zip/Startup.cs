﻿namespace _03_GenericSwapMethodStrings
{
    public class Startup
    {
        static void Main(string[] args)
        {
            Box<string> box = new Box<string>();

            int count = int.Parse(Console.ReadLine());

            for (int i = 0; i < count; i++)
            {
                box.Items.Add(Console.ReadLine());
            }

            int[] token = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray();

            List<string> result = box.Swap(box.Items, token[0], token[1]);

            foreach (var item in result)
            {
                Console.WriteLine($"{item.GetType()}: {item}");
            }



        }
    }
}