﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03_GenericSwapMethodStrings
{
    public class Box<T>
    {
        public List<T> Items { get; set; }

        public Box()
        {
            Items = new List<T>();
        }

        public List<T> Swap(List<T> swapList, int idx1, int idx2)
        {
            T firstElement = swapList[idx1];
            swapList[idx1] = swapList[idx2];
            swapList[idx2] = firstElement;

            return swapList;
        }
    }
}
