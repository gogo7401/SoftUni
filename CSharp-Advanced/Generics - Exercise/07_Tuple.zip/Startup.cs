﻿using _04_GenericSwapMethodInteger;

namespace _07_Tuple
{
    public class Startup
    {
        static void Main(string[] args)
        {
            var firstInput = new Box<string, string>();
            var secondInput = new Box<string, int>();
            var thirdInput = new Box<int, double>();

            string[] firtsLine = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            firstInput.Item1 = firtsLine[0] + " " + firtsLine[1];
            firstInput.Item2 = firtsLine[2];

            string[] secondLine = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            secondInput.Item1 = secondLine[0];
            secondInput.Item2 = int.Parse(secondLine[1]);

            string[] thirdLine = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            thirdInput.Item1 = int.Parse(thirdLine[0]);
            thirdInput.Item2 = double.Parse(thirdLine[1]);


            Console.WriteLine(firstInput.ToString());
            Console.WriteLine(secondInput.ToString());
            Console.WriteLine(thirdInput.ToString());
        }
    }
}