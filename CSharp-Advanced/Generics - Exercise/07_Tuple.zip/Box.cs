﻿using System.Text;

namespace _04_GenericSwapMethodInteger
{
    public class Box<T1, T2>
    {
        public T1  Item1 { get; set; }
        public T2 Item2 { get; set;}

        public override string ToString()
        {
            return $"{Item1} -> {Item2}";
        }

    }
}
