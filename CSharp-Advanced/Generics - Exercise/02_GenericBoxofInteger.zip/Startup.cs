﻿namespace _02_GenericBoxofInteger
{
    public class Startup
    {
        static void Main(string[] args)
        {
            Box<int> list = new Box<int>(); 

            int count = int.Parse(Console.ReadLine());

            for (int i = 0; i < count; i++)
            {
                list.Items.Add(int.Parse(Console.ReadLine()));
            }

            Console.WriteLine(list.ToString());
        }
    }
}