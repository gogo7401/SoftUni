﻿namespace _04_GenericSwapMethodInteger
{
    public class Startup
    {
        static void Main(string[] args)
        {
            Box<int> box = new Box<int>();

            int count = int.Parse(Console.ReadLine());

            for (int i = 0; i < count; i++)
            {
                box.Items.Add(int.Parse(Console.ReadLine()));
            }

            int[] token = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray();

            box.Swap(token[0], token[1]);

            Console.WriteLine(box.ToString());
        }
    }
}