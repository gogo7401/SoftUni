﻿using _04_GenericSwapMethodInteger;

namespace _08_Threeuple
{
    public class Startup
    {
        static void Main(string[] args)
        {
            var firstInput = new Box<string, string, string>();
            var secondInput = new Box<string, int, bool>();
            var thirdInput = new Box<string, double, string>();

            string[] firtsLine = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            firstInput.Item1 = $"{firtsLine[0]} {firtsLine[1]}";
            firstInput.Item2 = firtsLine[2];
            firstInput.Item3 = firtsLine[3];

            string[] secondLine = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            secondInput.Item1 = secondLine[0];
            secondInput.Item2 = int.Parse(secondLine[1]);
            secondInput.Item3 = secondLine[2] == "drunk";

            string[] thirdLine = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            thirdInput.Item1 = thirdLine[0];
            thirdInput.Item2 = double.Parse(thirdLine[1]);
            thirdInput.Item3 = thirdLine[2];


            Console.WriteLine(firstInput.ToString());
            Console.WriteLine(secondInput.ToString());
            Console.WriteLine(thirdInput.ToString());
        }
    }
}