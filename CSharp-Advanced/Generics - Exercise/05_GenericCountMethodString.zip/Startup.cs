﻿namespace _05_GenericCountMethodString
{
    public class Startup
    {
        static void Main(string[] args)
        {
            Box<string> list = new Box<string>();

            int numberOfElements = int.Parse(Console.ReadLine());

            for (int i = 0; i < numberOfElements; i++)
            {
                list.Items.Add(Console.ReadLine());
            }

            Console.WriteLine(list.CalculateCount(Console.ReadLine()));    
        }
    }
}