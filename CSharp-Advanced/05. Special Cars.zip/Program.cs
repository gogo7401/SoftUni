﻿namespace CustomSpecialCars
{
    public class ShowSpecialCars
    {
        static void Main(string[] args)
        {
            List<Tire[]> tiresList = new List<Tire[]>();
            List<Engine> enginesList = new List<Engine>();
            List<Car> carsList = new List<Car>();
            List<SpecialCar> specialCarList = new List<SpecialCar>();   

            string input = string.Empty;

            while ((input = Console.ReadLine()) != "No more tires")
            {
                string[] token = input.Split(" ", StringSplitOptions.RemoveEmptyEntries);

                int yearFirst = int.Parse(token[0]);
                double pressureFirst = double.Parse(token[1]);

                int yearSecond = int.Parse(token[2]);
                double pressureSecond = double.Parse(token[3]);

                int yearThird = int.Parse(token[4]);
                double pressureThird = double.Parse(token[5]);

                int yearFourth = int.Parse(token[6]);
                double pressureFourth = double.Parse(token[7]);

                Tire[] tires = new Tire[4]
                {
                    new Tire(yearFirst, pressureFirst),
                    new Tire(yearSecond, pressureSecond),
                    new Tire(yearThird, pressureThird),
                    new Tire(yearFourth, pressureFourth),
                };

                tiresList.Add(tires);

            }

            while ((input = Console.ReadLine()) != "Engines done")
            {
                string[] token = input.Split(" ", StringSplitOptions.RemoveEmptyEntries);

                int horsePower = int.Parse(token[0]);
                double cubicCapacity = double.Parse(token[1]);

                Engine engine = new Engine(horsePower, cubicCapacity);

                enginesList.Add(engine);
            }

            while ((input = Console.ReadLine()) != "Show special")
            {
                // {make} {model} {year} {fuelQuantity} {fuelConsumption} {engineIndex} {tiresIndex}
                string[] token = input.Split(" ", StringSplitOptions.RemoveEmptyEntries);

                string make = token[0];
                string model = token[1];
                int year = int.Parse(token[2]);
                double fuelQuantity = double.Parse(token[3]);
                double fuelConsumption = double.Parse(token[4]);
                int engineIndex = int.Parse(token[5]);
                int tiresIndex = int.Parse(token[6]);

                Car car = new Car(make, model, year, fuelQuantity, fuelConsumption, engineIndex, tiresIndex);

                carsList.Add(car);
            }

            // Find Special cars
            foreach (var car in carsList)
            {
                if (car.Year >= 2017 && enginesList[car.EngineIndex].HorsePower > 330 && isLikePressure(tiresList[car.TiresIndex][0].Pressure, tiresList[car.TiresIndex][1].Pressure, tiresList[car.TiresIndex][2].Pressure, tiresList[car.TiresIndex][3].Pressure))
                {
                    double fuelQuentityExists = car.FuelQuantity - (20 * car.FuelConsumption * 0.01);

                    SpecialCar specialCar = new SpecialCar(car.Make, car.Model, car.Year, enginesList[car.EngineIndex].HorsePower, fuelQuentityExists);

                    specialCarList.Add(specialCar);
                }
            }

            foreach (var specialCar in specialCarList)
            {
                Console.WriteLine($"Make: {specialCar.Make}\r\nModel: {specialCar.Model}\r\nYear: {specialCar.Year}\r\nHorsePowers: {specialCar.HorsePower}\r\nFuelQuantity: {specialCar.FuelQuantity}");
            }

            bool isLikePressure(double p1, double p2, double p3, double p4)
            {
                double sum = 0.0;
                sum = p1 + p2 + p3 + p4;
                if (sum >= 9 && sum <= 10)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

    }


}