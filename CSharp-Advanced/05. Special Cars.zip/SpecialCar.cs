﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomSpecialCars
{
    public class SpecialCar
    {
        public SpecialCar(string make, string model, int year, int horsePower, double fuelQuantity)
        {
            Make = make;
            Model = model;
            Year = year;
            HorsePower = horsePower;
            FuelQuantity = fuelQuantity;
        }

        public string Make { get; set; }

        public string Model { get; set; }

        public int Year { get; set; }

        public int HorsePower { get; set; }

        public double FuelQuantity { get; set; }
    }
}
