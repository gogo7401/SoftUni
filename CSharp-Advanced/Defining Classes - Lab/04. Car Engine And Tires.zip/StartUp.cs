﻿namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Tire[] tyres = new Tire[4]
            {
                new Tire(2020, 2.0),
                new Tire(2021, 2.1),
                new Tire(2022, 2.2),
                new Tire(2023, 2.3),
            };

            Engine engine = new Engine(530, 6300);

            Car car = new Car("Lamborghini", "Urus", 2010, 200, 2.4, engine, tyres);

            //Console.WriteLine($"{car.Make}, {car.Model}, {car.Year}, {car.FuelQuantity}, {car.FuelConsumption}, {car.Engine.HoursePower}, {car.Engine.CubicCapacity}, {car.Tires[0].Year} - {car.Tires[0].Pressure}");
        }
    }
}