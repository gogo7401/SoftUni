﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01_ListyIterator
{
    public class ListyIterator<T>
    {
        private List<T> list;   

        private int index;
        public ListyIterator(params T[] items)
        {
            list = new List<T>(items);
            index = 0;
        }

        public bool Move()
        {
            if (++index < list.Count)
            {
                return true;
            }
            index--;
            return false;
        }

        public bool HasNext()
        {
            int currentIndex = index;
            if (currentIndex+1 < list.Count)
            {
                return true;
            }
            return false;
        }

        public void Print()
        {
            if (list.Count>0)
            {
                Console.WriteLine(list[index]);
            }
            else
            {
                Console.WriteLine("Invalid Operation!");
            }
        }

    }
}
