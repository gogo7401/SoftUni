﻿namespace _01_ListyIterator
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
            ListyIterator<string> iterator = new ListyIterator<string>();
            
            while (true)
            {



                string[] input = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

                string command = input[0];


                string[] tokens = new string[input.Length - 1];

                for (int i = 1; i < input.Length; i++)
                {
                    tokens[i - 1] = input[i];
                }

                switch (command)
                {
                    case "Create":
                        iterator = new ListyIterator<string>(tokens);

                        break;


                    case "Move":
                        Console.WriteLine(iterator.Move());
                        break;

                    case "Print":
                        iterator.Print();
                        break;

                    case "HasNext":
                        Console.WriteLine(iterator.HasNext());
                        break;

                    case "END":
                        return;
                        break;

                }
            }

        }
    }
}