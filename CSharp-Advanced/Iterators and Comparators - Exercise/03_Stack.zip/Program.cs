﻿namespace _03_Stack
{
    internal class Program
    {
        static void Main(string[] args)
        {
           MyStack<int> stack = new MyStack<int>();
            
            string input = string.Empty;

            while ((input = Console.ReadLine()) != "END")
            {
                string[] token = input.Split(new string[] { " ", ", "}, StringSplitOptions.RemoveEmptyEntries);

                string command = token[0];

                if (command == "Push")
                {
                    int[] arr = new int[token.Length - 1];
                    for (int i = 1; i < token.Length; i++)
                    {
                        arr[i - 1] = Convert.ToInt32(token[i]);
                    }

                    stack.Push(arr);

                }
                else
                {
                    stack.Pop();
                }
            }

            foreach (int item in stack)
            {
                Console.WriteLine(item);
            }

            foreach (int item in stack)
            {
                Console.WriteLine(item);
            }
        }
    }
}