﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03_Stack
{
    public class MyStack<T> : IEnumerable<T>
    {
        private readonly Stack<T> _stack;

        private int _index;

        public MyStack()
        {
            _stack = new Stack<T>();
        }

        public void Push(params T[] input)
        {
            for (int i = 0; i < input.Length; i++)
            {
                _stack.Push(input[i]);
            }
        }

        public void Pop()
        {
            if (_stack.Count > 0)
            {
                _stack.Pop();
            }
            else
            {
                Console.WriteLine("No elements");
            }
        }




        public IEnumerator<T> GetEnumerator()
        {
            return _stack.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
