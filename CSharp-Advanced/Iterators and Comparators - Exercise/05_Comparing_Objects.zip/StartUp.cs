﻿namespace _05_Comparing_Objects
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<Person> people = new List<Person>();   
            
            string input = string.Empty;

            while ((input = Console.ReadLine()) != "END")
            {
                string[] token = input.Split(" ", StringSplitOptions.RemoveEmptyEntries);

                Person person = new Person(token[0], int.Parse(token[1]), token[2]);

                people.Add(person);

            }

            int number = int.Parse(Console.ReadLine());

            int countOfEqual = 0;
            

            foreach (Person person in people)
            {
                if (person.CompareTo(people[number-1]) == 0)
                {
                    countOfEqual++;
                }
            }

            if (countOfEqual > 1)
            {
                Console.WriteLine($"{countOfEqual} {people.Count - countOfEqual} {people.Count}");
            }
            else
            {
                Console.WriteLine("No matches");
            }
        }
    }
}