﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_Froggy
{
    public class Lake<T> : IEnumerable<int>
    {
        private List<int> listOfStones;

        public Lake(params int[] input)
        {
            listOfStones = new List<int>(input);
        }

        public IEnumerator<int> GetEnumerator()
        {
            for (int i = 0; i < listOfStones.Count; i++)
            {
                if (i % 2 == 0)
                {
                    yield return listOfStones[i];
                }
            }

            for (int i = listOfStones.Count-1; i > 0; i--)
            {
                if ( i % 2 != 0)
                {
                    yield return listOfStones[i];
                }
            }

        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
