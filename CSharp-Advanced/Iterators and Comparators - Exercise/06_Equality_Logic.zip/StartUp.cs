﻿namespace _06_Equality_Logic
{
    public class StartUp
    {
        static void Main(string[] args)
        {
           HashSet<Person> listHashSet = new HashSet<Person>();

            SortedSet<Person> listSortedSet = new SortedSet<Person>();

            int count = int.Parse(Console.ReadLine());  

            for (int i = 0; i < count; i++)
            {
                string[] input = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

                Person person = new Person
                {
                    Name = input[0],
                    Age = int.Parse(input[1])
                };

                listHashSet.Add(person);
                listSortedSet.Add(person);
            }

            Console.WriteLine(listHashSet.Count);
            Console.WriteLine(listSortedSet.Count);
        }
    }
}