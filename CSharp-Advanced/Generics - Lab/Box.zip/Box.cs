﻿namespace BoxOfT
{
    public class Box<T>
    {
        private T Element;

        public List<T> Elements;

        public int Count { get { return Elements.Count; } }

        public Box()
        {
            Elements = new List<T>();
        }

        public void Add(T Element)
        {
            Elements.Add(Element);
        }

        public T Remove()
        {
            T current = Elements[Elements.Count - 1];
            Elements.RemoveAt(Elements.Count - 1);
            return current;
        }

    }
}
