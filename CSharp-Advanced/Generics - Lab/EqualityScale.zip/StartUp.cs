﻿namespace GenericScale
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var test = new EqualityScale<int>(5, 5);
            Console.WriteLine(test.AreEqual());
        }
    }
}