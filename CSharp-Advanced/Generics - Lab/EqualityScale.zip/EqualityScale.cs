﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericScale
{
    public class EqualityScale<T>
    {
        private T leftValue;
        
        private T rightValue;

        
        public EqualityScale(T left, T right)
        {
            leftValue = left;
            rightValue = right;
        }

        public bool AreEqual()
        {
            return leftValue.Equals(rightValue);
        }
    }
}
