﻿namespace IteratorsAndComparators
{
    public class Library
    {
        private List<Book> _books;
        public Library(params Book[] books)
        {
            _books = new List<Book>(books);
        }
    }
}
